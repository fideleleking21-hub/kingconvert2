const amountInput = document.getElementById('amount');
const fromCurrency = document.getElementById('fromCurrency');
const toCurrency = document.getElementById('toCurrency');
const convertedAmount = document.getElementById('convertedAmount');
const exchangeRateText = document.getElementById('exchangeRateText');
const swapBtn = document.getElementById('swapBtn');
const updateTime = document.getElementById('updateTime');

// Dictionnaire partiel (l'API fournit les codes, nous ajoutons les noms)
const currencyNames = {
    "USD": "Dollar américain", "EUR": "Euro", "GBP": "Livre sterling", "JPY": "Yen japonais",
    "CAD": "Dollar canadien", "AUD": "Dollar australien", "CHF": "Franc suisse", "CNY": "Yuan chinois",
    "INR": "Roupie indienne", "BRL": "Réal brésilien", "ZAR": "Rand sud-africain", "MAD": "Dirham marocain",
    "DZD": "Dinar algérien", "TND": "Dinar tunisien", "XOF": "Franc CFA (BCEAO)", "XAF": "Franc CFA (BEAC)",
    "EGP": "Livre égyptienne", "SAR": "Rial saoudien", "AED": "Dirham des Émirats"
};

async function init() {
    try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD');
        const data = await response.json();
        const codes = Object.keys(data.rates);

        // Tri alphabétique des codes (A, B, C...)
        codes.sort().forEach(code => {
            const name = currencyNames[code] || "Devise";
            const text = `${code} - ${name}`;
            fromCurrency.add(new Option(text, code));
            toCurrency.add(new Option(text, code));
        });

        fromCurrency.value = "EUR";
        toCurrency.value = "USD";

        amountInput.addEventListener('input', convert);
        fromCurrency.addEventListener('change', convert);
        toCurrency.addEventListener('change', convert);
        swapBtn.addEventListener('click', () => {
            const temp = fromCurrency.value;
            fromCurrency.value = toCurrency.value;
            toCurrency.value = temp;
            convert();
        });

        convert();
    } catch (e) {
        exchangeRateText.innerText = "Erreur de connexion";
    }
}

async function convert() {
    const amount = amountInput.value;
    const from = fromCurrency.value;
    const to = toCurrency.value;

    if (amount <= 0 || amount === "") {
        convertedAmount.innerText = "--";
        return;
    }

    try {
        const response = await fetch(`https://open.er-api.com/v6/latest/${from}`);
        const data = await response.json();
        const rate = data.rates[to];
        
        const total = (amount * rate).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
        convertedAmount.innerText = `${total} ${to}`;
        exchangeRateText.innerText = `1 ${from} = ${rate.toFixed(4)} ${to}`;
        updateTime.innerText = `Mis à jour à ${new Date().toLocaleTimeString()}`;
    } catch (e) {
        console.error("Erreur de conversion");
    }
}

init();